@extends('admin.template.main')

@section('title','Editar Categoria  '.'<b>'.$category->name.'</b>')


@section('content')

{!!  Form::open(['route'=>['categories.update', $category->id] , 'method'=>'PUT']) !!}


<div class="form-group">

{!! Form::label('name','Nombre') !!}

{!! Form::text('name',$category->name,['class'=>'form-control','placeholder'=>'Nombre Completo','required']) !!}
</div>








<div class="form-group">

{!! Form::submit('Editar' ,['class'=>'btn btn-large btn-block btn-primary']) !!}

</div>



{!!  Form::close() !!}


@endsection
