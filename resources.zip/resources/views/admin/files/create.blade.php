@extends('admin.template.main')

@section('title',  'Agregar File')

@section('content')

{!!  Form::open(['route'=>'files.store','method'=>'POST']) !!}

<div class="form-group">
{!! Form::label('name','Nombre') !!}

{!! Form::text('name',null,['class'=>'form-control','placehoolder'=>'Nombre del  File','required']) !!}


</div>
<div class="form-group">

{!! Form::submit('Registrar',['class'=>'btn btn-primary']) !!}


</div>

{!!Form::close() !!}



@endsection