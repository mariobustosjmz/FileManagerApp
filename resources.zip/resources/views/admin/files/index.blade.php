@extends('admin.template.main')

@section('title','Lista de Files')


@section('content')

<a href="{{ route('files.create') }}" class="btn btn-primary"> File Nuevo</a>
<hr>

<table class="table table-striped">
	<thead>
		<th>ID</th>
		<th>Nombre</th>
		<th>Acciones </th>
  	</thead>

	<tbody>
		@foreach($files as $categoryfile)
		<tr>
			<td>{{$file->id}}</td>
			<td>{{$file->name}}</td>


			<td><a href="{{route('files.edit' , $file->id) }}" class="btn btn-warning"><span class="glyphicon glyphicon-pencil
			"></span></a> <a href="{{ route('admin.files.destroy', $file->id) }}" class="btn btn-danger"><span class="glyphicon glyphicon-remove
				"></span></a> </td>
			</tr>
			@endforeach
		</tbody>

	</table>

	{!! $files->render() !!}


	@endsection


